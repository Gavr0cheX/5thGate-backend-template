const db = require('../admin/database');

class Client {
  constructor(name, phone, email, address) {
    this.name = name;
    this.phone = phone;
    this.email = email;
    this.address = address;
  }

  // Get all clients
  static async getAllClients() {
    let sql = `SELECT * FROM clients`;
    return db.query(sql);
  }

  // Get client by ID
  static async findById(id) {
    let sql = `SELECT * FROM clients WHERE id = '${id}' LIMIT 1`;
    return db.query(sql);
  }

  // Create a new client
  static async createClient(name, phone, email, address) {
    let sql = `INSERT INTO clients (name, phone, email, address) 
               VALUES ('${name}', '${phone}', '${email}', '${address}')`;
    return db.query(sql);
  }

  // Update client details
  static async updateClient(id, name, phone, email, address) {
    let sql = `UPDATE clients 
               SET name = '${name}', phone = '${phone}', 
                   email = '${email}', address = '${address}' 
               WHERE id = '${id}'`;
    return db.query(sql);
  }

  // Delete client by ID
  static async deleteClient(id) {
    let sql = `DELETE FROM clients WHERE id = '${id}'`;
    return db.query(sql);
  }

  // Get units associated with a client
  static async getClientUnits(id) {
    let sql = `
      SELECT units.* 
      FROM units
      INNER JOIN client_units ON units.id = client_units.unit_id
      WHERE client_units.client_id = '${id}'
    `;
    return db.query(sql);
  }

  // Associate client with unit
  static async addUnitToClient(clientId, unitId) {
    let sql = `INSERT INTO client_units (client_id, unit_id) VALUES ('${clientId}', '${unitId}')`;
    return db.query(sql);
  }

  // Remove unit from client
  static async removeUnitFromClient(clientId, unitId) {
    let sql = `DELETE FROM client_units WHERE client_id = '${clientId}' AND unit_id = '${unitId}'`;
    return db.query(sql);
  }
}

module.exports = Client;
