const db = require('../admin/database');

class Unit {
  constructor(price, status, clientId, salesPrincipalId, type, area, floor, rentSale, finishing, roomNumber, bathroomNumber) {
    this.price = price;
    this.status = status;
    this.clientId = clientId;
    this.salesPrincipalId = salesPrincipalId;
    this.type = type;
    this.area = area;
    this.floor = floor;
    this.rentSale = rentSale;
    this.finishing = finishing;
    this.roomNumber = roomNumber;
    this.bathroomNumber = bathroomNumber;
  }

  // Get all units
  static async getAllUnits() {
    let sql = `SELECT * FROM units`;
    return db.query(sql);
  }

  // Get unit by ID
  static async findById(id) {
    let sql = `SELECT * FROM units WHERE id = '${id}' LIMIT 1`;
    return db.query(sql);
  }

  // Create a new unit
  static async createUnit(unitData) {
    const {
      price, status, clientId, salesPrincipalId, type, area, floor,
      rentSale, finishing, roomNumber, bathroomNumber
    } = unitData;
    let sql = `
      INSERT INTO units (price, status, client_id, sales_principal_id, type, area, floor, rent_or_sale, finishing, room_number, bathroom_number)
      VALUES ('${price}', '${status}', '${clientId}', '${salesPrincipalId}', '${type}', '${area}', '${floor}', '${rentSale}', '${finishing}', '${roomNumber}', '${bathroomNumber}')
    `;
    return db.query(sql);
  }

  // Update unit details
  static async updateUnit(id, unitData) {
    const {
      price, status, clientId, salesPrincipalId, type, area, floor,
      rentSale, finishing, roomNumber, bathroomNumber
    } = unitData;
    let sql = `
      UPDATE units
      SET price = '${price}', status = '${status}', client_id = '${clientId}', 
          sales_principal_id = '${salesPrincipalId}', type = '${type}', area = '${area}', 
          floor = '${floor}', rent_sale = '${rentSale}', finishing = '${finishing}', 
          room_number = '${roomNumber}', bathroom_number = '${bathroomNumber}'
      WHERE id = '${id}'
    `;
    return db.query(sql);
  }

  // Delete unit by ID
  static async deleteUnit(id) {
    let sql = `DELETE FROM units WHERE id = '${id}'`;
    return db.query(sql);
  }

  // Filter units (this could be customized further with more parameters)
  static async filterUnits(filters) {
    let { price, status, clientId, salesPrincipalId, type } = filters;
    let whereClause = "WHERE 1 = 1";

    if (price) {
      whereClause += ` AND price = '${price}'`;
    }
    if (status) {
      whereClause += ` AND status = '${status}'`;
    }
    if (clientId) {
      whereClause += ` AND client_id = '${clientId}'`;
    }
    if (salesPrincipalId) {
      whereClause += ` AND sales_principal_id = '${salesPrincipalId}'`;
    }
    if (type) {
      whereClause += ` AND type = '${type}'`;
    }

    let sql = `SELECT * FROM units ${whereClause}`;
    return db.query(sql);
  }

  // Get units associated with a specific client
  static async getUnitsByClientId(clientId) {
    let sql = `
      SELECT units.*
      FROM units
      INNER JOIN client_units ON units.id = client_units.unit_id
      WHERE client_units.client_id = '${clientId}'
    `;
    return db.query(sql);
  }
}

module.exports = Unit;
