exports.up = function(knex) {
    return knex.schema.table('clients', function(table) {
      // Add the missing 'email' and 'address' columns
      table.string('email', 255).notNullable().unique();  // Specify max length for email
      table.string('address', 255).notNullable();         // Specify max length for address
  
      // Rename the 'phone' column to 'mobile_number'
      table.renameColumn('mobile_number', 'phone');
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.table('clients', function(table) {
      // Drop the 'email' and 'address' columns in the 'down' migration
      table.dropColumn('email');
      table.dropColumn('address');
  
      // Rename 'mobile_number' column back to 'phone'
      table.renameColumn('phone', 'mobile_number');
    });
  };
  