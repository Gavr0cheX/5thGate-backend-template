const express = require('express');
const router = express.Router();
const unitController = require('../controllers/unitController');

// Get all units
router.get('/', unitController.getAllUnits);

// Get unit by ID
router.get('/:id', unitController.getUnitById);

// Create a new unit
router.post('/', unitController.createUnit);

// Update unit details
router.put('/:id', unitController.updateUnit);

// Delete unit by ID
router.delete('/:id', unitController.deleteUnit);

// Filter units by query parameters
router.get('/filter', unitController.filterUnits);

// Get units associated with a specific client
router.get('/client/:clientId', unitController.getUnitsByClientId);

module.exports = router;
