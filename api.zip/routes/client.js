const express = require('express');
const router = express.Router();
const clientController = require('../controllers/clientController');

// Get all clients
router.get('/', clientController.getAllClients);

// Get client by ID
router.get('/:id', clientController.getClientById);

// Create a new client
router.post('/', clientController.createClient);

// Update client details
router.put('/:id', clientController.updateClient);

// Delete client by ID
router.delete('/:id', clientController.deleteClient);

// Associate a unit with a client
router.post('/associate', clientController.associateUnitWithClient);

// Remove a unit from a client
router.post('/remove', clientController.removeUnitFromClient);

module.exports = router;
