const Unit = require('../models/unit');

// Get all units
const getAllUnits = async (req, res) => {
  try {
    const units = await Unit.getAllUnits();
    res.status(200).json(units);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching units' });
  }
};

// Get unit by ID
const getUnitById = async (req, res) => {
  const { id } = req.params;
  try {
    const unit = await Unit.findById(id);
    if (unit.length === 0) {
      return res.status(404).json({ message: 'Unit not found' });
    }
    res.status(200).json(unit);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching unit' });
  }
};

// Create a new unit
const createUnit = async (req, res) => {
  const unitData = req.body;

  try {
    await Unit.createUnit(unitData);
    res.status(201).json({ message: 'Unit created successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error creating unit' });
  }
};

// Update unit details
const updateUnit = async (req, res) => {
  const { id } = req.params;
  const unitData = req.body;

  try {
    const unit = await Unit.findById(id);
    if (unit.length === 0) {
      return res.status(404).json({ message: 'Unit not found' });
    }

    await Unit.updateUnit(id, unitData);
    res.status(200).json({ message: 'Unit updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating unit' });
  }
};

// Delete unit by ID
const deleteUnit = async (req, res) => {
  const { id } = req.params;

  try {
    const unit = await Unit.findById(id);
    if (unit.length === 0) {
      return res.status(404).json({ message: 'Unit not found' });
    }

    await Unit.deleteUnit(id);
    res.status(200).json({ message: 'Unit deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting unit' });
  }
};

// Filter units by different fields (optional filters)
const filterUnits = async (req, res) => {
  const filters = req.query;

  try {
    const units = await Unit.filterUnits(filters);
    res.status(200).json(units);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error filtering units' });
  }
};

// Get units by client ID
const getUnitsByClientId = async (req, res) => {
  const { clientId } = req.params;

  try {
    const units = await Unit.getUnitsByClientId(clientId);
    res.status(200).json(units);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching units for the client' });
  }
};

module.exports = {
  getAllUnits,
  getUnitById,
  createUnit,
  updateUnit,
  deleteUnit,
  filterUnits,
  getUnitsByClientId
};
